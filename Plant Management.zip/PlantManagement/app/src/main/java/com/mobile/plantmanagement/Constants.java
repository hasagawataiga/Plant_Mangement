package com.mobile.plantmanagement;

public class Constants {
    final static String LOGGED_IN = "LOGGED IN";
    final static String ACCOUNT_INFO = "ACCOUNT INFO";
    static int USER_INDEX = 1;
}
